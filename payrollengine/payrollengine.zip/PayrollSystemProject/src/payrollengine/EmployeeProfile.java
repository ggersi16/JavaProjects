package payrollengine;

public abstract class EmployeeProfile {
    private String firstName;
    private String lastName;
    private String employeeID;

    public EmployeeProfile(String firstName, String lastName, String employeeID) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.employeeID = employeeID;
    }

    public abstract double computePay();

    @Override
    public String toString() {
        return "Employee: " + firstName + " " + lastName + "\nID: " + employeeID;
    }

    public double calculateBonus() {
        return computePay() * 0.10;
    }
}
