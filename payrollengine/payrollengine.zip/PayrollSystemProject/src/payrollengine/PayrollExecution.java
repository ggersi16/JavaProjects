package payrollengine;

import java.util.Scanner;

public class PayrollExecution {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter total number of employees: ");
        int employeeCount = Integer.parseInt(scanner.nextLine());

        EmployeeProfile[] workforce = new EmployeeProfile[employeeCount];

        for (int i = 0; i < employeeCount; i++) {
            System.out.println("\n--- Employee #" + (i + 1) + " ---");

            System.out.println("Choose role (1=Full-Time, 2=Part-Time, 3=Sales, 4=Sales + Bonus): ");
            int option = Integer.parseInt(scanner.nextLine());

            System.out.print("First Name: ");
            String first = scanner.nextLine();

            System.out.print("Last Name: ");
            String last = scanner.nextLine();

            System.out.print("Employee ID: ");
            String identifier = scanner.nextLine();

            switch (option) {
                case 1:
                    System.out.print("Weekly Salary: ");
                    double weeklyWage = Double.parseDouble(scanner.nextLine());
                    workforce[i] = new FullTimeEmployee(first, last, identifier, weeklyWage);
                    break;

                case 2:
                    System.out.print("Total Hours: ");
                    double hoursWorked = Double.parseDouble(scanner.nextLine());
                    System.out.print("Hourly Rate: ");
                    double hourlyWage = Double.parseDouble(scanner.nextLine());
                    workforce[i] = new PartTimeEmployee(first, last, identifier, hoursWorked, hourlyWage);
                    break;

                case 3:
                    System.out.print("Sales Made: ");
                    double sales = Double.parseDouble(scanner.nextLine());
                    System.out.print("Commission Rate: ");
                    double rate = Double.parseDouble(scanner.nextLine());
                    workforce[i] = new ProductSalesAgent(first, last, identifier, sales, rate);
                    break;

                case 4:
                    System.out.print("Sales Made: ");
                    double totalSales = Double.parseDouble(scanner.nextLine());
                    System.out.print("Commission Rate: ");
                    double percentage = Double.parseDouble(scanner.nextLine());
                    System.out.print("Fixed Salary: ");
                    double base = Double.parseDouble(scanner.nextLine());
                    workforce[i] = new BonusBasedSeller(first, last, identifier, totalSales, percentage, base);
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
                    i--;
                    continue;
            }
        }

        System.out.println("\n============= Employee Overview =============\n");
        for (EmployeeProfile emp : workforce) {
            System.out.println(emp);
            System.out.printf("Pay for the Week: $%.2f\n", emp.computePay());
            System.out.println("------------------------------------------");
        }

        scanner.close();
    }
}
