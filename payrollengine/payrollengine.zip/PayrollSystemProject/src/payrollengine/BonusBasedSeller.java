package payrollengine;

public class BonusBasedSeller extends ProductSalesAgent {
    private double basePay;

    public BonusBasedSeller(String first, String last, String identifier,
                            double totalRevenue, double percentage, double basePay) {
        super(first, last, identifier, totalRevenue, percentage);
        this.basePay = basePay;
    }

    public double getBasePay() {
        return basePay;
    }

    public void setBasePay(double basePay) {
        this.basePay = basePay;
    }

    @Override
    public double computePay() {
        double extraPay = super.computePay();
        double bonus = 0.10 * basePay;
        return basePay + bonus + extraPay;
    }

    @Override
    public String toString() {
        return "Bonus-Based Seller: " + super.toString() +
               "\nBase Salary: $" + String.format("%.2f", basePay) +
               "\nBonus (10%): $" + String.format("%.2f", basePay * 0.10) +
               "\nTotal Pay: $" + String.format("%.2f", computePay());
    }
}