package payrollengine;

public class PartTimeEmployee extends EmployeeProfile {
    private double workedHours;
    private double hourlyRate;

    public PartTimeEmployee(String firstName, String lastName, String employeeID, double workedHours, double hourlyRate) {
        super(firstName, lastName, employeeID);
        this.workedHours = workedHours;
        this.hourlyRate = hourlyRate;
    }

    public double getWorkedHours() {
        return workedHours;
    }

    public void setWorkedHours(double workedHours) {
        this.workedHours = workedHours;
    }

    public double getHourlyRate() {
        return hourlyRate;
    }

    public void setHourlyRate(double hourlyRate) {
        this.hourlyRate = hourlyRate;
    }

    @Override
    public double computePay() {
        return workedHours * hourlyRate;
    }

    @Override
    public String toString() {
        return "Part-Time Employee: " + super.toString() +
               "\nHours Worked: " + workedHours +
               "\nHourly Pay: $" + hourlyRate +
               "\nWeekly Total: $" + computePay();
    }
}
