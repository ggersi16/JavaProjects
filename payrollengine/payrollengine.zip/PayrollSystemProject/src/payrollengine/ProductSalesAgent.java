package payrollengine;

public class ProductSalesAgent extends EmployeeProfile {
    private double salesFigure;
    private double incentiveRate;

    public ProductSalesAgent(String first, String last, String identifier, double salesFigure, double incentiveRate) {
        super(first, last, identifier);
        this.salesFigure = salesFigure;
        this.incentiveRate = incentiveRate;
    }

    public double getSalesFigure() {
        return salesFigure;
    }

    public void setSalesFigure(double salesFigure) {
        this.salesFigure = salesFigure;
    }

    public double getIncentiveRate() {
        return incentiveRate;
    }

    public void setIncentiveRate(double incentiveRate) {
        this.incentiveRate = incentiveRate;
    }

    @Override
    public double computePay() {
        return salesFigure * incentiveRate;
    }

    @Override
    public String toString() {
        return "Sales Agent: " + super.toString() +
               "\nTotal Sales: $" + String.format("%.2f", salesFigure) +
               "\nCommission: " + String.format("%.2f", incentiveRate * 100) + "%" +
               "\nEarnings: $" + String.format("%.2f", computePay());
    }
}
