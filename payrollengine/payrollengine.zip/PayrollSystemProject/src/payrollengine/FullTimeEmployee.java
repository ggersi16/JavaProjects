package payrollengine;

public class FullTimeEmployee extends EmployeeProfile {
    private double weeklySalary;

    public FullTimeEmployee(String firstName, String lastName, String employeeID, double weeklySalary) {
        super(firstName, lastName, employeeID);
        this.weeklySalary = weeklySalary;
    }

    public double getWeeklySalary() {
        return weeklySalary;
    }

    public void setWeeklySalary(double weeklySalary) {
        this.weeklySalary = weeklySalary;
    }

    @Override
    public double computePay() {
        return weeklySalary;
    }

    @Override
    public String toString() {
        return "Full-Time Employee: " + super.toString() +
               "\nWeekly Salary: $" + computePay();
    }
}
